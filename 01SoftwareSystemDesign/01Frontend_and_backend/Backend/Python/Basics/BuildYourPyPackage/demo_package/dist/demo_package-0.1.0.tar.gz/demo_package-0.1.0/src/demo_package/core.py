def add(a: float, b: float) -> float:
    return a + b
