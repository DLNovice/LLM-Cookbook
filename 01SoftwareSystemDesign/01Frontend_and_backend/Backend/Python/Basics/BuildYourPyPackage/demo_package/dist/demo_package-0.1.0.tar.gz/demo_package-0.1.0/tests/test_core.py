from demo_package import add

def test_add():
    assert add(1, 2) == 3
