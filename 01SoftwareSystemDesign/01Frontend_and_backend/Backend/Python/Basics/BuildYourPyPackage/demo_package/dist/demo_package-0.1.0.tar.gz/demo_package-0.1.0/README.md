# your_package

一个用于数学运算的简单 Python 库。

## 安装

```bash
pip install your_package
